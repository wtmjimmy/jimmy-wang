let forest
let sun
let butterfly

function preload(){
  forest = loadImage("forest.jpg")
  sun = loadImage("sun.png")
  butterfly = loadImage("butterfly.png")}

function setup(){
  createCanvas(400,400)
  textFont("Arial")}

function draw(){
  image(forest,0,0,width,height)
  
let sunSize = mouseX / 4 + 50
  image(sun,250,30,sunSize,sunSize)
  image(butterfly,mouseX,mouseY,80,80)

  fill(255,255,0)
  stroke(0)
  strokeWeight(2)
  textSize(24)
  text("Nature Scene",100,40)

  fill(255)
  stroke(0)
  textSize(16)
  text("Fly the butterfly and change the size of sun by moving the mouse",10,320,360,60)}