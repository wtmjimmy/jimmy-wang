function setup() {
  createCanvas(400, 400)

  screenColor = color("#FFEDC1")
  titleText = "SMART TV"
}

function draw() {
  background("#FAF8F4")

  fill("#2D2D2D")
  rect(50,50,300,200,15)

  fill(screenColor);
  rect(70,70,260,160,10)

  fill("#2D2D2D")
  textAlign(CENTER,CENTER)
  textSize(24)
  text(titleText,200,150)

  if( 
    mouseX > 70 &&
    mouseX < 150 &&
    mouseY > 300 &&
    mouseY < 340)
  
  {strokeWeight(3)
    stroke(255)}
   else {noStroke()}

  fill("#D96C4A")
  rect(70,300,80,40,10)

  if(
    mouseX > 160 &&
    mouseX < 240 &&
    mouseY > 300 &&
    mouseY < 340) 
  
  {strokeWeight(3)
    stroke(255)} 
  else {noStroke()}

  fill("#6D8B74")
  rect(160,300,80,40,10)

  if(dist(mouseX,mouseY,290,320) < 25){
    strokeWeight(3)
    stroke(255)}
  else{noStroke()}

  fill("#6C8EBF")
  ellipse(290,320,50,50)

  noStroke()
  fill(255)
  textSize(12)
  text("YT",110,320)
  text("D",200,320)
  text("NF",290,320)

  fill("#2D2D2D")
  rect(180,250,40,30)
  rect(150,280,100,12)}

function mousePressed(){
  if(
    mouseX > 70 &&
    mouseX < 150 &&
    mouseY > 300 &&
    mouseY < 340)
    
    {screenColor = color("#FFE5D4")
    titleText = "YOUTUBE"}

  if(dist(mouseX,mouseY,290,320) < 25){
    screenColor = color("#DCE8F5")
    titleText = "NETFLIX"}}

function keyPressed(){
  if(
    mouseX > 160 &&
    mouseX < 240 &&
    mouseY > 300 &&
    mouseY < 340){

    if(key === "d"){
      screenColor = color("#DDE8D5")
      titleText = "DISNEY+"}}
}
