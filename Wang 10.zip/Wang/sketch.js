function setup(){
  createCanvas(800,600,WEBGL)
  background("#0b1026")
  brush.scaleBrushes(2);

  brush.set("HB", "#ffffff",0.8)
  brush.set("marker", "#8fd3ff",1.5)

  brush.line(-330,-220,-180,-150)
  brush.line(-180,-150,-140,-140)

  brush.fill("#ffffff",120)
  brush.circle(-140,-140,10)

  brush.line(120,-250,280,-160)
  brush.line(280,-160,330,-140)
  brush.circle(330,-140,10)

  brush.fill("#7b61ff",120)
  brush.circle(-170,60,180)

  brush.fill("#a997ff",100)
  brush.circle(-210,20,20)

  brush.noFill()
  brush.hatch(8,65)
  brush.rect(-170,60,220,40,"center")
  
  brush.fill("#ff9f43",120)
  brush.circle(200,-30,110)

  brush.fill("#ffd29b",100)
  brush.circle(170,-55,35)

  brush.fill("#b0b8c0",120)
  brush.circle(310,40,35)

  brush.set("HB", "#d0d7dd",0.8)
  brush.line(260,10,295,30)

  brush.fill("#56cfe1",110)
  brush.circle(-300,200,40)

  brush.fill("#80ffdb",110)
  brush.circle(-240,240,25)

  brush.fill("#ffd166",110)
  brush.circle(-340,260,18)}
