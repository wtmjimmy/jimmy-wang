function setup(){
  createCanvas(400,400)
  angleMode(DEGREES)

  let suns = getSunCount()
  print("Number of suns: " + suns)
    background(135,206,235)
  for (let i = 0; i < suns; i++){
  drawSun(70 + i * 80,200,0.7 + i * 0.2, i * 15)}}

function drawSun(x,y,s,r){
  push()
  translate(x,y)
  scale(s)
  rotate(r)

  fill(255,204,0)
  noStroke()
  circle(0,0,50)

  stroke(255,204,0)
  strokeWeight(3)
  line(-40,0,-25,0)
  line(40,0,25,0)
  line(0,-40,0,-25)
  line(0,40,0,25)
  pop()}

function getSunCount(){return 4}