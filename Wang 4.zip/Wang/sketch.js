let moonX = 50
let skyColor

function setup() {
  createCanvas(400, 400)
  skyColor = color(20,30,80)}

function draw() {
  
  background(skyColor)
  fill(255,240,0)
  noStroke()
  circle(50,50,4)
  circle(120,80,3)
  circle(200,40,5)
  circle(280,90,4)
  circle(350,60,3)

  moonX = moonX + 1

  if (moonX > width+30)
  {moonX = -30}
  
  fill(240)
  circle(moonX,180,60)
  fill(40,100,50)
  rect(0,300,400,100)

  for(let i = 0; i < 400; i += 20)
  {line(i,300,i,400)}
  
  if (mouseX > 200)
  {fill(255, 220, 120)}
  else {fill(240)}
  circle(moonX, 180, 60)
    
  if (keyIsPressed) {moonX = moonX + 3}}
  
function mouseClicked()
  {if (red(skyColor) < 100)
  {skyColor = color(150, 220, 255)}
  else {skyColor = color(20, 30, 80)}
}