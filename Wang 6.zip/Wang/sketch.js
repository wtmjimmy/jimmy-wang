let pumpkins = [60,140,220,300,380]
let bats = []

function setup(){
  createCanvas(400,400)
  print("Pumpkins length: " + pumpkins.length)
  for(let i = 0; i < 5; i++){bats[i] = i * 80}}

function draw(){
  background(15,15,40)
  fill(255,245,180)
  circle(320,70,80)

  fill(255)
  circle(50,50,4)
  circle(90,80,4)
  circle(150,40,4)
  circle(230,90,4)
  circle(280,30,4)

  fill(0)
    for (let i = 0; i < bats.length; i++){
    ellipse(bats[i],120,20,10)
    bats[i] += 2
    if (bats[i] > width + 10){bats[i] = -10}}

  fill(40,80,40)
  rect(0,300,400,100)
 
  for (let i = 0; i < pumpkins.length; i++){
    fill(255,140,0)
    circle(pumpkins[i],270,45)
    fill(0,150,0)
    rect(pumpkins[i] - 2,240,4,10)}
  pumpkins[0] = mouseX
}